# Information Security — Lab Coursework

This repository documents the practical lab work completed for the
**Information Security** subject. Each folder corresponds to one topic
assigned by the faculty and contains:

- **Objective** — what the lab is meant to teach
- **Concepts** — the theory behind it (for viva/explanation)
- **Tools Used** — software used in the lab
- **Steps Performed** — commands and procedure, in order
- **Sample Output / Observations** — what the tool showed and what it means
- **Conclusion** — what was learned

## Topic Index

| # | Topic | Folder |
|---|-------|--------|
| 1 | Introduction to Security Tools and Environment Setup | [01-intro-security-tools](./01-intro-security-tools) |
| 2 | Linux System Administration Basics | [02-linux-sysadmin-basics](./02-linux-sysadmin-basics) |
| 3 | Virtual Machine Setup and Management | [03-vm-setup-management](./03-vm-setup-management) |
| 4 | Network Configuration and Diagnostics | [04-network-config-diagnostics](./04-network-config-diagnostics) |
| 5 | Packet Capture and Traffic Analysis | [05-packet-capture-traffic-analysis](./05-packet-capture-traffic-analysis) |
| 6 | Network Scanning and Enumeration | [06-network-scanning-enumeration](./06-network-scanning-enumeration) |
| 7 | Vulnerability Assessment | [07-vulnerability-assessment](./07-vulnerability-assessment) |
| 8 | Password Security and Authentication | [08-password-security-authentication](./08-password-security-authentication) |
| 9 | Cryptography Fundamentals | [09-cryptography-fundamentals](./09-cryptography-fundamentals) |
| 10 | Web Application Security Testing | [10-web-app-security-testing](./10-web-app-security-testing) |
| 11 | Firewall Configuration and Access Control | [11-firewall-config-access-control](./11-firewall-config-access-control) |
| 12 | System Log Monitoring and Analysis | [12-log-monitoring-analysis](./12-log-monitoring-analysis) |
| 13 | Malware Identification and Safe Analysis | [13-malware-identification-safe-analysis](./13-malware-identification-safe-analysis) |
| 14 | Incident Response and Security Reporting | [14-incident-response-reporting](./14-incident-response-reporting) |
| 15 | Security Audit and Best Practices | [15-security-audit-best-practices](./15-security-audit-best-practices) |

## Lab Environment

- **Host OS:** Windows/macOS/Linux (your machine)
- **Hypervisor:** VirtualBox / VMware Workstation
- **Guest VMs:**
  - Kali Linux (attacker/analysis machine — pre-loaded with security tools)
  - Metasploitable2 / OWASP Broken Web Apps (intentionally vulnerable target, used ONLY inside an isolated lab network)
  - Ubuntu Server (general-purpose Linux practice)
- **Networking mode:** VirtualBox "Internal Network" or "Host-only", so lab traffic never touches the real internet or a shared network

> **Note on ethics:** All scanning, exploitation, and traffic-capture exercises
> in this repository were performed **only** against machines I own or
> intentionally vulnerable lab VMs (e.g., Metasploitable2) running in an
> **isolated virtual network**. None of these techniques were used against
> any system without authorization. This matches standard academic practice
> for security coursework (OWASP, Offensive Security, SANS labs all follow
> the same rule).

## How to Use This Repo for Viva/Explanation

Each topic README is written so you can read it top-to-bottom and explain:
1. **What** the tool/concept is
2. **Why** it matters in real-world security work
3. **How** you used it (exact commands)
4. **What the output means**

If your faculty asks "explain this," walk through those four points in order.
